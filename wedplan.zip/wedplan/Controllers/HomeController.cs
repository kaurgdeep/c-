﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using wedplan.Models;
using Microsoft.EntityFrameworkCore;


namespace wedplan.Controllers
{
    public class HomeController : Controller
    {
        private WedContext _context;

        public HomeController (WedContext context) {
            _context = context;
        }
        
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Dashboard()
        {
            // List<User> Alluser = _context.user.ToList ();
            User users = _context.users.SingleOrDefault(us => us.Email == HttpContext.Session.GetString("user"));
            ViewBag.User = users;

            List<Wedding> Allweddings = _context.weddings.Include(i => i.Guests).ToList ();
           
            ViewBag.Wedding = Allweddings;

            return View();
        }

        [Route("Home/delete/{id}")]
        public IActionResult delete(int id)
        {
            Wedding Removewedding = _context.weddings.SingleOrDefault(w => w.WeddingId == id);
            _context.weddings.Remove(Removewedding);
            _context.SaveChanges();

            return RedirectToAction("Dashboard");
        }
        [Route("Home/RSVP/{id}")]
        public IActionResult RSVP(int id)
        {
            Guest guest = new Guest();
            guest.WeddingId = id;
            User users = _context.users.SingleOrDefault(us => us.Email == HttpContext.Session.GetString("user"));
            guest.UserId = users.UserId;
            _context.Add(guest);
            _context.SaveChanges();

            Wedding Wedding = _context.weddings.SingleOrDefault(wd => wd.WeddingId == id);
            Wedding.Guests.Add(guest);

            return RedirectToAction("Dashboard");
        }

       [Route("Home/Details/{id}")]

        public IActionResult Details(int id)
        {
            var ids = id;
            Wedding Wedding = _context.weddings.SingleOrDefault(wd => wd.WeddingId == id);
            List<Wedding> Guests = _context.weddings.Include(ig => ig.Guests).ToList();
            ViewBag.Wedding = Wedding;
            ViewBag.Guests = Guests;
            return View("Details");
        }

        [Route("Home/Logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        [Route("Home/NewWedding")]
        public IActionResult NewWedding()
        {
            User users = _context.users.SingleOrDefault(us => us.Email == HttpContext.Session.GetString("userEmail"));
            ViewBag.User = users;
            
            return View();
        }
        [HttpPost]
        [Route("process")]
        public IActionResult process(Wedding createwedding){
            if (ModelState.IsValid){
            User users = _context.users.SingleOrDefault(us => us.Email == HttpContext.Session.GetString("user"));
            createwedding.UserId = users.UserId;
            _context.Add(createwedding);
            _context.SaveChanges(); 
            return RedirectToAction("Details");
            }
            else
            {
                return RedirectToAction("NewWedding");
            }
        }
        [Route("Home/dashboardbutton")]
        public IActionResult dashboardbutton()
        {
            return RedirectToAction("Dashboard");
        }

       

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        [Route ("RegisterUser")]
        public IActionResult RegisterUser (User MyUser, string ConfirmPassword) {
            
            System.Console.WriteLine ("WE HIT REGISTERED USER FUNCTION IN CONTROLLER");
            if(MyUser.Password != ConfirmPassword) {
                System.Console.WriteLine("DAMN HOMIE your passwords dont match **************************");
                ViewBag.PasswordError = $"{MyUser.FirstName} I'm so terribly sorry but I'm a robot and I don't understand why you would type passwords that don't match. THANKS FOR PLAYING. TRY AGAIN!";
                return View ("Index");
            }

            if (ModelState.IsValid) {
                PasswordHasher<User> Hasher = new PasswordHasher<User>();
                MyUser.Password = Hasher.HashPassword(MyUser, MyUser.Password);
                User ExistingUser = _context.users.SingleOrDefault (u => u.Email == MyUser.Email);
                if (ExistingUser != null) {
                    System.Console.WriteLine (" *************EMAIL ALREADY IN USE**********************");
                    ViewBag.AlreadyInUseEmail = true;
                    // ViewBag.AlreadyInUseEmail = $"{MyUser.Email} is already in the Data base, YOU FUCK!";
                    return View ("Index");
                    // Yo dude Have you ever watched Mike Tyson Mysteries? Its really good show.
                }
                else{
                    _context.Add (MyUser);
                    _context.SaveChanges ();
                    HttpContext.Session.SetString("useremail", MyUser.Email);
                    return RedirectToAction ("Dashboard");
                }
            } else {
                System.Console.WriteLine ("There were errors adding user returned to index********************");
                return View ("Index");
            }

        }

        [HttpPost]
        [Route("LoginUser")]
        public IActionResult Login(string email, string Password){
            
            var users = _context.users.SingleOrDefault(u => u.Email == email);
            if(users != null && Password != null){
                var Hasher = new PasswordHasher<User>();
                if(0 != Hasher.VerifyHashedPassword(users, users.Password, Password)){
                    HttpContext.Session.SetString("user", email);
                    return RedirectToAction("Dashboard");
                }
                else{
                    System.Console.WriteLine("*************************$$$$$$$$$$$#################################$$$$$$$$$$$$$$************");
                    System.Console.WriteLine("Else for login if password doesnt match");
                    System.Console.WriteLine("*************************$$$$$$$$$$$#################################$$$$$$$$$$$$$$************");

                    ViewBag.loginError = "Wrong password!";
                    return View("Index");
                }
            }
            else{
                System.Console.WriteLine("*************************$$$$$$$$$$$#################################$$$$$$$$$$$$$$************");
                System.Console.WriteLine("Else for login email doesnt exist");
                System.Console.WriteLine("*************************$$$$$$$$$$$#################################$$$$$$$$$$$$$$************");

                ViewBag.loginError = "Email not registered";
                return View("Index");
            }

       
            
        }
        
    }
}
