using System;
namespace view_model_fun.Models
{
    public class User
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}