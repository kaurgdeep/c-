using System.ComponentModel.DataAnnotations;

namespace LoginRegDemo
{
    public class Participant
    {
        [Key]
        public int PaticipantId {get; set;}


    }
}

